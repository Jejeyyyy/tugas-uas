import React from 'react';
import { ViewState } from '../types';
import Icon from './Icon';

interface NavigationProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
  hasActiveTicket: boolean;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, setView, hasActiveTicket }) => {
  return (
    <div className="fixed bottom-0 left-0 w-full bg-white border-t border-gray-200 pb-safe z-50">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto">
        <button
          onClick={() => setView('home')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
            currentView === 'home' ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          <Icon name="Home" size={24} />
          <span className="text-[10px] font-medium">Layanan</span>
        </button>
        
        <button
          onClick={() => setView('ticket')}
          disabled={!hasActiveTicket}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 relative ${
            currentView === 'ticket' ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
          } ${!hasActiveTicket ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {hasActiveTicket && (
              <span className="absolute top-2 right-6 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
          )}
          <Icon name="Ticket" size={24} />
          <span className="text-[10px] font-medium">Tiket Saya</span>
        </button>

        <button
          onClick={() => setView('assistant')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
            currentView === 'assistant' ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          <Icon name="MessageSquareText" size={24} />
          <span className="text-[10px] font-medium">Asisten</span>
        </button>
      </div>
    </div>
  );
};

export default Navigation;
