import React from 'react';
import { ServiceDefinition } from '../types';
import Icon from './Icon';

interface ServiceCardProps {
  service: ServiceDefinition;
  onClick: (service: ServiceDefinition) => void;
  currentQueueLength: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, onClick, currentQueueLength }) => {
  return (
    <button
      onClick={() => onClick(service)}
      className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-all text-left flex items-start space-x-4 w-full active:scale-[0.98]"
    >
      <div className={`p-3 rounded-lg bg-blue-50 text-blue-600`}>
        <Icon name={service.icon} size={24} />
      </div>
      <div className="flex-1">
        <h3 className="font-semibold text-gray-800 text-sm md:text-base">{service.name}</h3>
        <p className="text-xs text-gray-500 mt-1 line-clamp-2">{service.description}</p>
        <div className="mt-2 flex items-center space-x-3 text-xs">
          <span className="flex items-center text-gray-600 bg-gray-100 px-2 py-0.5 rounded-full">
            <Icon name="Users" size={12} className="mr-1" />
            {currentQueueLength} antrian
          </span>
          <span className="flex items-center text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
            <Icon name="Clock" size={12} className="mr-1" />
            ~{currentQueueLength * service.estimatedTimePerPerson} mnt
          </span>
        </div>
      </div>
    </button>
  );
};

export default ServiceCard;
