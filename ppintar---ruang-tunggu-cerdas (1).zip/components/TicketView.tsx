import React from 'react';
import { Ticket, ServiceDefinition } from '../types';
import Icon from './Icon';

interface TicketViewProps {
  ticket: Ticket;
  service: ServiceDefinition;
  onCancel: () => void;
  userName: string;
}

const TicketView: React.FC<TicketViewProps> = ({ ticket, service, onCancel, userName }) => {
  // Format Date nicely
  const dateObj = new Date(ticket.date);
  const dateStr = dateObj.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div className="flex flex-col h-full bg-gray-50 p-4 overflow-y-auto pb-24">
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden relative">
        {/* Decorative top pattern */}
        <div className="h-4 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500"></div>
        
        <div className="p-6 text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center">
                 <Icon name={service.icon} size={32} />
            </div>
          </div>
          
          <h2 className="text-gray-500 text-sm font-medium uppercase tracking-wider mb-1">Kode Booking</h2>
          <span className="text-4xl font-mono font-bold text-gray-800 tracking-wider block mb-6">{ticket.number}</span>

          <div className="border-t border-dashed border-gray-300 my-4 relative">
             <div className="absolute -left-8 -top-3 w-6 h-6 bg-gray-50 rounded-full"></div>
             <div className="absolute -right-8 -top-3 w-6 h-6 bg-gray-50 rounded-full"></div>
          </div>

          <div className="space-y-4 text-left">
            <div>
                <p className="text-xs text-gray-400">Nama Pemohon</p>
                <p className="font-semibold text-gray-800">{userName}</p>
            </div>
            <div>
                <p className="text-xs text-gray-400">Layanan</p>
                <p className="font-semibold text-gray-800">{service.name}</p>
            </div>
            
            <div className="bg-green-50 p-4 rounded-xl border border-green-100">
                <div className="flex items-start space-x-3">
                    <Icon name="CalendarCheck" size={20} className="text-green-600 mt-0.5" />
                    <div>
                        <p className="text-xs text-green-700 font-semibold uppercase">Jadwal Terkonfirmasi</p>
                        <p className="text-sm font-bold text-gray-800 mt-1">{dateStr}</p>
                        <p className="text-xl font-bold text-blue-600 mt-1">{ticket.timeSlot}</p>
                    </div>
                </div>
            </div>
          </div>

          <div className="mt-6 text-xs text-gray-500 bg-gray-100 p-3 rounded-lg">
             Harap datang 15 menit sebelum jadwal. Tunjukkan kode booking ini kepada petugas di loket pendaftaran.
          </div>
        </div>

        {/* QR Code Simulation */}
        <div className="bg-gray-900 p-4 flex items-center justify-between text-white">
           <div className="flex flex-col">
             <span className="text-xs text-gray-400">ID Tiket</span>
             <span className="font-mono text-sm">{ticket.id.slice(0, 12).toUpperCase()}</span>
           </div>
           <div className="bg-white p-1 rounded">
             <Icon name="QrCode" size={24} className="text-black" />
           </div>
        </div>
      </div>

      <div className="mt-6">
         <h4 className="font-semibold text-gray-700 mb-2 px-1">Butuh Bantuan?</h4>
         <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <p className="text-sm text-gray-600 mb-2">
                Bingung syarat dokumen apa saja yang harus dibawa untuk <strong>{service.name}</strong>?
            </p>
            <div className="flex items-center text-blue-600 text-sm font-medium">
                <Icon name="Bot" size={16} className="mr-2" />
                Tanya Asisten AI di menu bawah
            </div>
         </div>
      </div>

      <button 
        onClick={onCancel}
        className="mt-6 w-full py-3 text-red-500 font-medium text-sm hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-100"
      >
        Batalkan Jadwal
      </button>
    </div>
  );
};

export default TicketView;