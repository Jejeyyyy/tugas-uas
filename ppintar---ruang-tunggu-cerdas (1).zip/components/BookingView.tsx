import React, { useState } from 'react';
import { ServiceDefinition } from '../types';
import { TIME_SLOTS } from '../constants';
import Icon from './Icon';

interface BookingViewProps {
  service: ServiceDefinition;
  onConfirm: (date: string, timeSlot: string) => void;
  onBack: () => void;
}

const BookingView: React.FC<BookingViewProps> = ({ service, onConfirm, onBack }) => {
  // Generate next 3 days for demo
  const generateDates = () => {
    const dates = [];
    const today = new Date();
    for (let i = 1; i <= 5; i++) { // Start from tomorrow
        const d = new Date(today);
        d.setDate(today.getDate() + i);
        dates.push({
            label: d.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short' }),
            value: d.toISOString().split('T')[0],
            dayName: d.toLocaleDateString('id-ID', { weekday: 'long' })
        });
    }
    return dates;
  };

  const dates = generateDates();
  const [selectedDate, setSelectedDate] = useState<string>(dates[0].value);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  return (
    <div className="flex flex-col h-full bg-gray-50">
       {/* Header */}
       <div className="bg-white p-4 flex items-center shadow-sm z-10 sticky top-0">
          <button onClick={onBack} className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full">
            <Icon name="ArrowLeft" size={24} />
          </button>
          <h2 className="ml-2 font-bold text-gray-800">Pilih Jadwal</h2>
       </div>

       <div className="flex-1 overflow-y-auto p-4 pb-24">
          {/* Service Info */}
          <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm mb-6 flex items-start space-x-3">
             <div className="bg-blue-50 p-3 rounded-lg text-blue-600">
                <Icon name={service.icon} size={24} />
             </div>
             <div>
                <h3 className="font-semibold text-gray-800">{service.name}</h3>
                <p className="text-xs text-gray-500">{service.description}</p>
             </div>
          </div>

          {/* Date Selection */}
          <h3 className="text-sm font-bold text-gray-700 mb-3 ml-1">Pilih Tanggal</h3>
          <div className="flex space-x-3 overflow-x-auto pb-2 scrollbar-hide mb-6">
             {dates.map((d) => (
                <button
                    key={d.value}
                    onClick={() => setSelectedDate(d.value)}
                    className={`flex-shrink-0 w-24 p-3 rounded-xl border flex flex-col items-center justify-center transition-all ${
                        selectedDate === d.value 
                        ? 'bg-blue-600 border-blue-600 text-white shadow-md' 
                        : 'bg-white border-gray-200 text-gray-600 hover:border-blue-300'
                    }`}
                >
                    <span className="text-xs opacity-80">{d.value.split('-')[2]}</span>
                    <span className="text-sm font-bold">{d.label.split(',')[0]}</span>
                </button>
             ))}
          </div>

          {/* Time Slots */}
          <h3 className="text-sm font-bold text-gray-700 mb-3 ml-1">Pilih Jam Kedatangan</h3>
          <div className="grid grid-cols-2 gap-3 mb-6">
             {TIME_SLOTS.map((slot) => {
                 // Randomly disable some slots to simulate fullness
                 const isFull = (slot === "09:00 - 10:00" && selectedDate === dates[0].value);
                 return (
                    <button
                        key={slot}
                        disabled={isFull}
                        onClick={() => setSelectedSlot(slot)}
                        className={`p-3 rounded-xl text-sm font-medium border transition-all ${
                            isFull 
                            ? 'bg-gray-100 border-gray-100 text-gray-400 cursor-not-allowed decoration-slice' 
                            : selectedSlot === slot
                                ? 'bg-blue-600 border-blue-600 text-white shadow-md'
                                : 'bg-white border-gray-200 text-gray-600 hover:border-blue-400'
                        }`}
                    >
                        {slot} {isFull && <span className="text-[10px] block font-normal">(Penuh)</span>}
                    </button>
                 );
             })}
          </div>
       </div>

       {/* Bottom Action */}
       <div className="p-4 bg-white border-t border-gray-200 fixed bottom-0 left-0 w-full z-20">
          <button 
             onClick={() => selectedSlot && onConfirm(selectedDate, selectedSlot)}
             disabled={!selectedSlot}
             className="w-full bg-blue-600 text-white py-3.5 rounded-xl font-semibold shadow-lg shadow-blue-200 disabled:opacity-50 disabled:shadow-none transition-all active:scale-[0.98]"
          >
             Konfirmasi Jadwal
          </button>
       </div>
    </div>
  );
};

export default BookingView;