import React, { useState } from 'react';
import Icon from './Icon';

interface LoginViewProps {
  onLoginSuccess: (user: any) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleGoogleLogin = () => {
    // SIMULASI LOGIN GOOGLE
    // Di dunia nyata (tugas kuliah), Anda akan menggunakan library 'Google Identity Services'
    // Referensi: https://developers.google.com/identity/gsi/web/guides/overview
    
    setIsLoading(true);
    
    // Simulasi delay jaringan
    setTimeout(() => {
        const mockUser = {
            name: "Mahasiswa Pintar",
            email: "mahasiswa@univ.ac.id",
            avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix"
        };
        setIsLoading(false);
        onLoginSuccess(mockUser);
    }, 1500);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-600 to-indigo-800 p-6 text-white text-center">
      <div className="mb-8 p-6 bg-white/10 backdrop-blur-md rounded-3xl shadow-2xl border border-white/20">
        <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg text-blue-600">
            <Icon name="Building2" size={40} />
        </div>
        <h1 className="text-3xl font-bold mb-2">PPintar</h1>
        <p className="text-blue-100 text-sm max-w-[200px] mx-auto">Layanan Pemerintah dalam Genggaman</p>
      </div>

      <div className="w-full max-w-sm space-y-4">
        <p className="text-sm text-blue-100 mb-6">Silakan masuk untuk melakukan reservasi layanan KTP, KK, SIM, dll.</p>

        {/* Tombol Google Sign In Custom */}
        <button
          onClick={handleGoogleLogin}
          disabled={isLoading}
          className="w-full bg-white text-gray-700 hover:bg-gray-50 active:bg-gray-100 font-medium rounded-lg px-4 py-3 transition-all flex items-center justify-center shadow-lg relative overflow-hidden"
        >
          {isLoading ? (
             <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-gray-300 border-t-blue-600 rounded-full animate-spin"></div>
                <span>Menghubungkan...</span>
             </div>
          ) : (
            <>
               <img 
                 src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" 
                 alt="Google G" 
                 className="w-5 h-5 mr-3"
               />
               <span>Sign in with Google</span>
            </>
          )}
        </button>
        
        <p className="text-xs text-blue-200 mt-8">
            &copy; {new Date().getFullYear()} PPintar Gov Services
        </p>
      </div>
    </div>
  );
};

export default LoginView;