import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const sendMessageToGemini = async (message: string, history: string[]): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    
    // Construct a context-aware prompt
    const systemPrompt = `
      Anda adalah "PintarBot", asisten virtual ramah di kantor layanan publik "PPintar" (Pusat Pelayanan Pintar) di Indonesia.
      Tugas Anda adalah membantu masyarakat yang sedang mengantri dengan memberikan informasi akurat tentang:
      1. Syarat-syarat pembuatan dokumen (KTP, KK, Paspor, Akta Lahir, SIM, dll).
      2. Estimasi waktu layanan.
      3. Prosedur birokrasi di Indonesia secara umum.
      
      Gunakan bahasa Indonesia yang sopan, formal namun mudah dimengerti. 
      Jika ditanya tentang antrian spesifik pengguna, jelaskan bahwa Anda adalah AI dan sarankan mereka melihat tiket di aplikasi.
      Jawablah dengan ringkas dan gunakan poin-poin (bullet points) jika menjelaskan persyaratan.
    `;

    // Simple implementation for chat context: append history to the current prompt if needed, 
    // but for this simple app, we will rely on a single-turn rich prompt or handle chat history via the Chat API if complex.
    // Here we use generateContent for simplicity with system instructions.

    const response = await ai.models.generateContent({
      model: model,
      contents: message,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      }
    });

    return response.text || "Maaf, saya tidak dapat memproses permintaan Anda saat ini.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Maaf, terjadi kesalahan koneksi dengan server asisten.";
  }
};
